﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class right : MonoBehaviour
{
    
    public bool rightchck;
    public GameObject player;
    public GameObject nxtlvlscreen;
    public GameObject wrongtext;


    // Start is called before the first frame update

    // Update is called once per frame
    void OnTriggerEnter2D(Collider2D hitInfo){
        if(rightchck){
            nxtlvlscreen.SetActive(true);
            player.GetComponent<PlayerController2D>().enabled = false;
        }else{
            PlayerController2D.wrongcount +=1;
        }
    }
    void Update() {
        wrongtext.GetComponent<UnityEngine.UI.Text>().text = "Wrong Option Selected: " + PlayerController2D.wrongcount.ToString() + " times";
    }
}
