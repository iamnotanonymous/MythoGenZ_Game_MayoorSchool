﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Buttonsscript : MonoBehaviour
{
    public GameObject pausescreen;
    public bool ispaused = false; 
    public GameObject Player;
    public GameObject start1;
    public GameObject start2;
    public GameObject start3;
    public GameObject start4;
    public AudioSource startsound;
 
    public void pausescreenld(){
        if(!(ispaused)){
        pausescreen.SetActive(true);
        Player.GetComponent<PlayerController2D>().enabled = false;
        ispaused = true;
        }else{
        pausescreen.SetActive(false);
        Player.GetComponent<PlayerController2D>().enabled = true;
        ispaused = false;
        }
    }

    public void Quitappbttn(){
        Application.Quit();
    }

    public void Creditbttn(){
        SceneManager.LoadScene(2);
    }

    public void Homebttn(){
        SceneManager.LoadScene(0);
    }

    public void startlvl(){
        StartCoroutine(startlvlv());
    }

    public void lvl1(){
        StartCoroutine(lvlloader(3));
    }
    public void lvl2(){
        StartCoroutine(lvlloader(5));
    }

    public void lvl3(){
        StartCoroutine(lvlloader(7));
    }
    
    public void quiz1(){
        StartCoroutine(lvlloader(4));
    }
    public void quiz2(){
        StartCoroutine(lvlloader(6));
    }

    public void reloadlvlbut(){
        StartCoroutine(reloadcor());
    }
    IEnumerator reloadcor(){
        yield return new WaitForSeconds(2);
        PlayerController2D.scorelvl = 0;
        PlayerController2D.arrowused = 0;
        Scene scene = SceneManager.GetActiveScene(); 
        SceneManager.LoadScene(scene.name);
    }

    IEnumerator startlvlv(){
        start1.SetActive(true);
        startsound.Play();
        yield return new WaitForSeconds(1);
        start1.SetActive(false);
        start2.SetActive(true);
        yield return new WaitForSeconds(1);
        start2.SetActive(false);
        start3.SetActive(true);
        yield return new WaitForSeconds(1);
        start3.SetActive(false);
        start4.SetActive(true);
        yield return new WaitForSeconds(1);
        SceneManager.LoadScene(1);
    }

    IEnumerator lvlloader(int t){
        PlayerController2D.scorelvl = 0;
        PlayerController2D.arrowused = 0;
        yield return new WaitForSeconds(1);
        SceneManager.LoadScene(t);
    }
}
