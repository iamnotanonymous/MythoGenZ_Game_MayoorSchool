﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialArrow1 : MonoBehaviour
{
    private Rigidbody2D rb;
    private bool chck = true;
    private Animator animator; 
    private BoxCollider2D bxcol;

    void Start()
    {
        animator = transform.GetComponent<Animator>();
        rb = transform.GetComponent<Rigidbody2D>();  
        bxcol = transform.GetComponent<BoxCollider2D>();
        rb.velocity = transform.up * 10f;
        StartCoroutine(destroygm(30));
        gameObject.transform.Rotate(0f, 0f, 90f, Space.World);
        PlayerController2D.arrowused += 1;
    }

    void Update() {
        if(rb.velocity.y < 0 && chck){
            gameObject.transform.Rotate(0f, 0f, 180f, Space.World);
            chck = false;
        }    
    }

    void OnTriggerEnter2D(Collider2D hitInfo){
        Debug.Log(hitInfo.name);
        rb.velocity = transform.up * 0f;
        rb.gravityScale = 0f;
        bxcol.enabled = false;
        StartCoroutine(destroygm(1.1f));
        animator.SetBool("trigger", true); 
        if (hitInfo.name != "Enemy" && hitInfo.name != "Player" && hitInfo.name != "CrouchCheck"){
            FindObjectOfType<AudioManager>().play("hitarrow");

        }
    }

    IEnumerator destroygm(float t)
    {
        yield return new WaitForSeconds(t);
        Destroy(gameObject);
    }
}
