﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpecialArrow : MonoBehaviour
{
    private Rigidbody2D rb;
    private Animator animator; 

    void Start()
    {
        animator = transform.GetComponent<Animator>();
        rb = transform.GetComponent<Rigidbody2D>();  
        rb.velocity = transform.right * 15f;
        StartCoroutine(destroygm(30));
        PlayerController2D.arrowused += 1;
    }
    void OnTriggerEnter2D(Collider2D hitInfo){
        Debug.Log(hitInfo.name);
        rb.velocity = transform.right * 0f;
        rb.gravityScale = 0f;
        StartCoroutine(destroygm(1.1f));
        animator.SetBool("trigger", true); 
        if (hitInfo.name != "Enemy" && hitInfo.name != "Player" && hitInfo.name != "CrouchCheck"){
            FindObjectOfType<AudioManager>().play("hitarrow");
        }
    }

    IEnumerator destroygm(float t)
    {
        yield return new WaitForSeconds(t);
        Destroy(gameObject);
    }
}
