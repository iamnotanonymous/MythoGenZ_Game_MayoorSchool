using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController2D : MonoBehaviour
{
    [SerializeField] private LayerMask platformLayerMask;   
    private Rigidbody2D rbb;                          
    public Transform firePoint;
    private PolygonCollider2D bxcol;                    
    private CircleCollider2D crcol;                         
    private Animator animator;                             
    private bool direcchck = true;                          
    private bool Isjump;                                    
    private float direc;             
    public static float scorelvl = 0f;   
    public static float arrowused = 0f;                 
    private float yspeed;                                
    private float xspeed;                               
    private float IsCrouch; 
    private float time;  
    public static int wrongcount = 0;
    private float time2;
    public static int methit = 0;
    public static int hitmet = 0;
    public GameObject arrowPrefab;
    public GameObject arrowPrefab2;
    public GameObject killedtext;
    public GameObject usedtext;

    
    //Runs the Code at Start
    void Start() 
    {
        bxcol = transform.GetComponent<PolygonCollider2D>();   
        crcol = transform.GetComponent<CircleCollider2D>(); 
        rbb = transform.GetComponent<Rigidbody2D>();        
        animator = transform.GetComponent<Animator>();     
    }
    
    //Runs Once every frame
    void Update()
    {

        killedtext.GetComponent<UnityEngine.UI.Text>().text = "Fish Score: " + scorelvl.ToString() + "/9";
        usedtext.GetComponent<UnityEngine.UI.Text>().text = "Arrows Used: " + arrowused.ToString();

        Debug.Log(scorelvl);
        direc = Input.GetAxis("Horizontal");                
        Isjump = Input.GetButtonDown("Jump");              
        IsCrouch = Input.GetAxisRaw("Crouch");             

        if (Isjump && IsGrounded())
        {
            xspeed = rbb.velocity.x;
            rbb.velocity = new Vector3(xspeed, 10f, 0);
        }
        
        if (IsCrouch != 0f && !(IsGrounded()) && rbb.velocity.y < 0.01f)
        {
            rbb.gravityScale = 2.4f;
        }else{
            rbb.gravityScale = 3f;     
        }

  
        if (IsCrouch != 0f)
        {
            bxcol.enabled = false; 
            animator.SetBool("Crouch", true);
        }else if (!(ShouldUncrouch()))
        {
            bxcol.enabled = true;                          
            animator.SetBool("Crouch", false);
        }


    }

    void FixedUpdate() {
        animator.SetFloat("Speed", Mathf.Abs(direc));       

        if (IsCrouch == 0f && !(ShouldUncrouch()))              
        {
            yspeed = rbb.velocity.y;
            rbb.velocity = new Vector3(4 * direc, yspeed, 0);
        }else if (IsCrouch != 0f || ShouldUncrouch())   
        {
            yspeed = rbb.velocity.y;
            rbb.velocity = new Vector3(1 * direc, yspeed, 0); 
        }

        if (direc > 0 && !(direcchck))
        {
            transform.Rotate(0f, 180f, 0f);                                        
            direcchck = true;
        }else if (direc < 0 && direcchck)
        {
            transform.Rotate(0f, 180f, 0f);                                         
            direcchck = false;
        }    
        //Ends   
        if(Input.GetAxisRaw("Fire1") > 0.05f && time < 0f)
        {
            Shoot();
            time = 50f;
            FindObjectOfType<AudioManager>().play("bow");
            animator.SetBool("Shoot", true); 
        }else if(time > 0f){
            animator.SetBool("Shoot", false); 
        } 
        time -= 1f;

        if(Input.GetAxisRaw("Fire2") > 0.05f && time2 < 0f)
        {
            Shoott();
            time2 = 150f;
            FindObjectOfType<AudioManager>().play("bow");
            animator.SetBool("Shoot", true); 
        }else if(time2 > 0f){
            animator.SetBool("Shoot", false); 
        } 
        time2 -= 1f;
    }
    

    private bool IsGrounded() {                            
        float extraHeightText = 0.1f;
        RaycastHit2D raycastHit = Physics2D.BoxCast(crcol.bounds.center, crcol.bounds.size, 0f, Vector2.down, extraHeightText, platformLayerMask);
        return raycastHit.collider != null;
    }

    public bool ShouldUncrouch() {                        
        if (transform.Find("CrouchCheck").GetComponent<CrouchCheck>().isCrouchCheck){
            return true;
        }
        return false;
    }    
    private void Shoot(){
        Instantiate(arrowPrefab, firePoint.position, firePoint.rotation);
    }
    private void Shoott(){
        Instantiate(arrowPrefab2, firePoint.position, firePoint.rotation);
    }
}