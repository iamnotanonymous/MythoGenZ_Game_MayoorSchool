﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class finish : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject nxtlvl;
    public GameObject Player;

    // Update is called once per frame
    void Update()
    {
        Debug.Log(PlayerController2D.hitmet);
        if(PlayerController2D.hitmet == 4){
            nxtlvl.SetActive(true);
            Player.GetComponent<PlayerController2D>().enabled = true;
        }
    }
}
