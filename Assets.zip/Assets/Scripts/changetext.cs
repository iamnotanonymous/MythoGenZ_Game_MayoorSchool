﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class changetext : MonoBehaviour
{
    private Animator animator; 
    public static bool allowbird = false;
    void Start()
    {
        animator = transform.GetComponent<Animator>();
    }

    // Start is called before the first frame update
    void OnTriggerEnter2D(Collider2D hitInfo){
        if(hitInfo.name == "Player" && allowbird==false){
            animator.SetBool("interact", true);
            allowbird = true;
            StartCoroutine(destroygm(10.1f));
        }
    }
    IEnumerator destroygm(float t)
    {
        yield return new WaitForSeconds(t);
        animator.SetBool("interact", false);
    }
}
