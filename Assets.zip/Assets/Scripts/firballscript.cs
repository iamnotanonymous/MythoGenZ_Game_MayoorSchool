﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class firballscript : MonoBehaviour
{
    public Rigidbody2D rb;
    public float posx;
    private bool check = true;
    public float posx2;
    public float speed = 1f;
    private bool check2 = true;
    // Start is called before the first frame update
    void Start()
    {
        rb = transform.GetComponent<Rigidbody2D>(); 
        PlayerController2D.methit = 0;
        PlayerController2D.hitmet = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (check && rb.position.x < posx)
        {
            rb.velocity = new Vector3(2 * speed, 0, 0);
            transform.rotation = new Quaternion(0f, 0f, -180f, 1);
        }
        if (check && rb.position.x > posx2)
        {
            rb.velocity = new Vector3(-2 * speed, 0, 0);
            transform.rotation = new Quaternion(0f, 0f, 0f, 1);
        }

        if (PlayerController2D.methit >= 10){
            StartCoroutine(reloadcor());
        }
    }
    void OnTriggerEnter2D(Collider2D hitInfo){
        string n = hitInfo.name;
        Debug.Log(n);
        if (n == "Player"){
            PlayerController2D.methit += 1;
        }
        if (n != "Player" && check2){
        if(n.Substring(0,7) == "Arrow 2"){
        float x = rb.velocity.x;
        rb.velocity = new Vector3(x, -5f, 0);
        check = false;
        check2 = false; 
        PlayerController2D.hitmet += 1;
        StartCoroutine(destroygm(2)); 
        }
        }
    }

    IEnumerator reloadcor(){
        yield return new WaitForSeconds(2);
        PlayerController2D.scorelvl = 0;
        PlayerController2D.arrowused = 0;
        Scene scene = SceneManager.GetActiveScene(); 
        SceneManager.LoadScene(scene.name);
    }

    IEnumerator destroygm(float t)
    {
        yield return new WaitForSeconds(t);
        Destroy(gameObject);
    }
}
