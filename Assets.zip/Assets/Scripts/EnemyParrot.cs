﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class EnemyParrot : MonoBehaviour
{
    public Rigidbody2D rb;
    private Animator animator; 
    public GameObject Player;
    public GameObject nxtlvlscrn;

    // Start is called before the first frame update
    void Start()
    {
        rb = transform.GetComponent<Rigidbody2D>(); 
        animator = transform.GetComponent<Animator>(); 
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter2D(Collider2D hitInfo){
        if(changetext.allowbird == true){
        Debug.Log(hitInfo.name);
        rb.gravityScale = 1f;  
        animator.SetBool("Dead", true);
        StartCoroutine(destroygm(30));      
        }
    }
    IEnumerator destroygm(float t)
    {
        yield return new WaitForSeconds(2);
        nxtlvlscrn.SetActive(true);
        Player.GetComponent<PlayerController2D>().enabled = false;
        yield return new WaitForSeconds(t);
        Destroy(gameObject);
    }
}
