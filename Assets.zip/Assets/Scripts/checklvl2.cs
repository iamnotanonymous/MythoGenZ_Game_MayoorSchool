﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class checklvl2 : MonoBehaviour
{

    public GameObject nxtlvlscrn;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (PlayerController2D.scorelvl == 9){
            nxtlvlscrn.SetActive(true);
        }
    }
}
