﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishPrefab : MonoBehaviour
{
    public Rigidbody2D rb;
    private Animator animator; 
    private bool check = true;
    public bool secondarrow = false;
    public float posy;
    public float posy2;
    public float speed = 1f;

    // Start is called before the first frame update
    void Start()
    {
        rb = transform.GetComponent<Rigidbody2D>(); 
    }

    // Update is called once per frame
    void Update()
    {
        if (check && rb.position.y <= posy)
        {
            rb.velocity = new Vector3(0, 2 * speed, 0);
        }
        if (check && rb.position.y >= posy2)
        {
            rb.velocity = new Vector3(0, -2 * speed, 0);
        }
    }

    void OnTriggerEnter2D(Collider2D hitInfo){
        string g = hitInfo.name;
        if(g.Substring(0,5) == "Arrow" && check && !(secondarrow)){
        Debug.Log(hitInfo.name);
        rb.gravityScale = 1f;
        StartCoroutine(destroygm(60));
        check = false;  
        PlayerController2D.scorelvl += 1;   
        }else if(g.Substring(0,7) == "Arrow 1" && check && secondarrow){
        Debug.Log(hitInfo.name);
        rb.gravityScale = 1f;
        StartCoroutine(destroygm(60));
        check = false;  
        PlayerController2D.scorelvl += 4;
        }
    }
    IEnumerator destroygm(float t)
    {
        yield return new WaitForSeconds(t);
        Destroy(gameObject);
    }
}
