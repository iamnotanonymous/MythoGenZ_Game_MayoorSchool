﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Reload : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D hitInfo){
        if(hitInfo.name == "Player"){
            StartCoroutine(reloadcor());
        }
    }

    IEnumerator reloadcor(){
        yield return new WaitForSeconds(2);
        PlayerController2D.scorelvl = 0;
        PlayerController2D.arrowused = 0;
        Scene scene = SceneManager.GetActiveScene(); 
        SceneManager.LoadScene(scene.name);
    }
}
