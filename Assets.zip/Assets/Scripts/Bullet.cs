﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public Rigidbody2D rb;
    private bool check = true;
    public BoxCollider2D bulletw;

    void Start()
    {
        rb = transform.GetComponent<Rigidbody2D>();  
        rb.velocity = transform.right * 15f;
        StartCoroutine(destroygm());
        PlayerController2D.arrowused += 1;
    }
    void OnTriggerEnter2D(Collider2D hitInfo){
        if (check){
        Debug.Log(hitInfo.name);
        rb.velocity = transform.right * 0f;
        rb.gravityScale = 2f;
        check = false;
        bulletw.enabled = false;
        gameObject.transform.Rotate(0f, 0f, -90f, Space.World);
        if (hitInfo.name != "Enemy" && hitInfo.name != "Player" && hitInfo.name != "CrouchCheck"){
            FindObjectOfType<AudioManager>().play("hitarrow");

        }
    }
    }

    IEnumerator destroygm()
    {
        yield return new WaitForSeconds(10);
        Destroy(gameObject);
    }
}
